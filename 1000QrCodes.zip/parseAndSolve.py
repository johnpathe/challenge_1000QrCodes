#!/usr/bin/python
import os
from base64 import standard_b64decode as b64d
from PIL import Image
import numpy as np
from qrtools import QR

# i think i had to do a bit of googling to make qrtools work properly, something related to `apt install python-zbar`... can't remember.



# this takes the original ctf challenge files in the original/ folder and converts the base64 into lines of x x x x x (text qr stuff)

# then it pads the top and sides with a margin, 5 modules thick


marginWidth = 5

padder = ((' ' * 29) + '\n')



for i in os.listdir('original/'):
    with open('original/' + i) as file:
        originalText = file.read()

    decodedText = b64d(originalText)

    with open('qrtext/' + i, 'w') as file:
        file.write(decodedText)


for i in os.listdir('qrtext/'):
    with open('qrtext/' + i) as file:
       allLines = file.readlines()

    with open('qrtext2/' + i, 'w') as file:
        file.write(padder)
        file.write(padder)
        file.write(padder)
        file.write(padder)
        file.write(padder)

        file.writelines(allLines)

        file.write('\n')
        file.write(padder)
        file.write(padder)
        file.write(padder)
        file.write(padder)
        file.write(padder)


for i in os.listdir('qrtext2/'):

    with open('qrtext2/' + i) as file:
        allLines = file.readlines()

    allLines2 = []

    for line in allLines:
        line = ((' ' * marginWidth) + line)
        line = line.replace('\n', (' ' * marginWidth) + '\n')
        allLines2.append(line)

    with open('qrtext2/' + i, 'w') as file:
        file.writelines(allLines2)




# built up the qrtext2/ folder with a separate process of decoding the base64
# changed the input text files to have 5 module margins with another python file padqrtext.py

# i realised qrtools couldn't decode the QRs because i was converting the x's in the
# qrtext2/ folder to 255 instead of 0's...

# qrtools could read qr1 but not others, i slept on it and litterally woke up realising 
# i needed to have margins around my qrcode images :P

# since the flag text is different enough from the non-flag text. i've just sorted the decoded data
# alphabetically to make this print the answer


def parseLine(line):
    newLine=[]
    for i in line:
        parsedChar = i.replace(" ", "255").replace("x","0").replace("\n", "")
        if not parsedChar == '':
            newLine.append(parsedChar)
    return newLine


def buildMatrix(filename):
    allLines = []
    
    with open(filename,'r') as file:
        line = parseLine(file.readline())
        while line:
                allLines.append(line)
                line = parseLine(file.readline())
    return allLines


def textInQrOut(inPath,outPath, format):
    for qrFile in os.listdir(inPath):
        QrArray = buildMatrix(inPath + qrFile)
        matrix = np.asarray(dtype='uint8', a=QrArray)

        i = Image.fromarray(matrix)
        i = i.resize(size = (464,464),resample = 0)
        i.save(outPath + qrFile + '.' + format)


outputPath = 'output/'

textInQrOut('qrtext2/',outputPath,'png')

candidates = []

allQRData = []

for qrImage in os.listdir(outputPath):
    qr = QR()
    qr.decode(outputPath + qrImage) 
    allQRData.append( qr.data + ',' + qrImage + '\n')
    
allQRData.sort()

print "Sorted all qr codes data alphabetically. The last few codes are ... "
print allQRData[-3:]

print "The flag is : " + allQRData[-1].split(',')[0]








